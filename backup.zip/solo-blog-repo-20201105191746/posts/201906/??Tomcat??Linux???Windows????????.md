title: 随笔 | Tomcat：续-从Linux迁移到Windows编码问题彻底解决
date: '2019-06-27 15:40:52'
updated: '2019-12-08 20:35:20'
tags: [随笔, Tomcat, Java]
permalink: /articles/2019/06/27/1561621252210.html
---
# 前言

继上条博文 [将Tomcat、MySQL从Linux迁移到Windows的心路历程（干货）：令人恐惧的字符编码](https://www.stackoverflow.wiki/blog/articles/2019/05/03/1556879549795.html) 后，我发现控制台随后仍出现了一些乱码，并不受到在**conf/logging.properties**文件修改**GBK**后的影响，它输出的**仍是UTF-8**，导致控制台仍然蓝屏。

# 排查方向

这次的错误排查，我换了个方向，上一次是**针对修改Tomcat的配置**，这一次是**在不变动Tomcat配置的情况下，让Windows适应其配置**。

# 解决问题

## 控制台编码

了解系统的朋友可能都知道，Windows的控制台默认使用**GBK编码**，而类Unix系统使用的大都是**UTF-8编码**，这也就导致了中文乱码的发生。

那么如何将Windows的控制台修改为**UTF-8**编码呢？

引用 [https://blog.csdn.net/qq_34273222/article/details/83508671](https://blog.csdn.net/qq_34273222/article/details/83508671)：

```
在运行中通过regedit进入注册表  
找到HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Command Processor  
新建-字符串值，命名autorun，右键修改：数值数据填写 “chcp 65001”，确定并重启计算机。
```

在设置后，每个命令行执行前都会执行一次`chcp 65001`，将默认的编码修改为**UTF-8**。

## 本窗口运行

但我发现，Tomcat的`startup.bat`运行后，会额外弹出一个窗口，这个窗口使用**Java控制台**来运行Tomcat，而不是使用**系统的控制台**，那么我们需要修改一下`startup.bat`中的配置让Tomcat在当前控制台中运行：

引用 [https://www.cnblogs.com/javaeye235/p/5552190.html](https://www.cnblogs.com/javaeye235/p/5552190.html)：

```
window下tomcat在当前窗口启动，不在一个新的窗口启动  
startup.bat  
中最下几行  
goto setArgs  
:doneSetArgs  
call "%EXECUTABLE%" start %CMD_LINE_ARGS%  
:end  
----------  
把start改为run  
call "%EXECUTABLE%" run %CMD_LINE_ARGS%
```

# 后语

再次运行Tomcat，编码问题成功解决，不需要配置繁琐的配置文件了。
