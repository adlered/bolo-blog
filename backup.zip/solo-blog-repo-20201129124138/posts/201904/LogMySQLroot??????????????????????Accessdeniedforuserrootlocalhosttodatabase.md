title: Log-MySQL root用户登录后无法查看数据库全部表/正常访问数据库 Access denied for user 'root'@'localhost'
  to database
date: '2019-04-11 11:44:09'
updated: '2019-12-09 09:47:28'
tags: [Log, MySQL]
permalink: /articles/2019/04/11/1554954249277.html
---
今天在对MySQL进行建表、权限设置之后，突然发现没有了数据库的操作权限：
```
mysql> show databases;
+--------------------+
| Database           |
+--------------------+
| mysql              |
+--------------------+
1 rows in set (0.00 sec)
```
WTF？我的数据库去哪了？
之后赶紧从外部访问了数据库，发现数据仍在，没有丢失。
此时我判断，可能是由于`root@localhost`的权限被清空导致的。因为`root@%`仍有全部的权限，但使用`root@localhost`进行表查询时会显示：
```
Access denied for user 'root'@'localhost' to database
```
那么，我只要重新将`root@localhost`的权限重置到最高权限，就可以了：
```
mysql> use mysql;
mysql> update user set `Select_priv` = 'Y', `Insert_priv` = 'Y', `Update_priv` = 'Y', `Delete_priv` = 'Y', `Create_priv` = 'Y', `Drop_priv` = 'Y', `Reload_priv` = 'Y', `Shutdown_priv` = 'Y', `Process_priv` = 'Y', `File_priv` = 'Y', `Grant_priv` = 'Y', `References_priv` = 'Y', `Index_priv` = 'Y', `Alter_priv` = 'Y', `Show_db_priv` = 'Y', `Super_priv` = 'Y', `Create_tmp_table_priv` = 'Y', `Lock_tables_priv` = 'Y', `Execute_priv` = 'Y', `Repl_slave_priv` = 'Y', `Repl_client_priv` = 'Y', `Create_view_priv` = 'Y', `Show_view_priv` = 'Y', `Create_routine_priv` = 'Y', `Alter_routine_priv` = 'Y', `Create_user_priv` = 'Y', `Event_priv` = 'Y', `Trigger_priv` = 'Y', `Create_tablespace_priv` = 'Y' where user='root' and host='localhost';
mysql> flush privileges;
```
重新在本地连接登录`root@localhost`，发现权限已恢复。
