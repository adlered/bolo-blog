title: 大白话之Docker(贰)：简单部署一个Tomcat服务并发布内容
date: '2019-03-19 22:12:03'
updated: '2019-12-09 09:48:55'
tags: [大白话, Docker]
permalink: /articles/2019/03/19/1553004723789.html
---
# 前言

看了上一章，想必你已经对Docker有所了解。
[如没有阅读过第一章，点我可以跳转至第一章](https://www.stackoverflow.wiki/blog/articles/2019/03/19/1552966314902.html)

Tomcat是基于Apache、支持JavaWeb环境的Web服务端。能对外提供网站服务。

本篇教程我们将简单建立一个Tomcat服务器，并部署一些内容到Tomcat中。

# 应用镜像到容器

### 取得镜像

首先，我们从`Docker源`中搜索**已经配置好环境的镜像**，然后应用到本地。

输入命令：

```
✘ adler@A ~/docker/tomcat: search tomcat
NAME                                       DESCRIPTION                                     STARS               OFFICIAL            AUTOMATED
tomcat                                     Apache Tomcat is an open source implementati…   2343                [OK]
tomee                                      Apache TomEE is an all-Apache Java EE certif…   64                  [OK]
dordoka/tomcat                             Ubuntu 14.04, Oracle JDK 8 and Tomcat 8 base…   53                                      [OK]
davidcaste/alpine-tomcat                   Apache Tomcat 7/8 using Oracle Java 7/8 with…   34                                      [OK]
```

眼花缭乱。仔细看有一列**OFFICIAL**，为**OK**的话，说明已经经过了官方的认证，我们使用第一行的**Tomcat**：这是Tomcat官方提供的镜像。

### 下载镜像

输入命令：

```
adler@A ~/docker/tomcat: docker pull tomcat
Using default tag: latest
latest: Pulling from library/tomcat
e79bb959ec00: Download complete
d4b7902036fe: Download complete
1b2a72d4e030: Pulling fs layer
de423484a946: Waiting
ceaac3b844f7: Waiting
88f01b722a52: Waiting
c23be56a9ac1: Waiting
d852ffd6d31f: Waiting
11775a3d792d: Waiting
13fdd17462ac: Waiting
2092995a1e54: Waiting
latest: Pulling from library/tomcat
e79bb959ec00: Pull complete
d4b7902036fe: Pull complete
1b2a72d4e030: Pull complete
de423484a946: Pull complete
ceaac3b844f7: Pull complete
88f01b722a52: Pull complete
c23be56a9ac1: Pull complete
d852ffd6d31f: Pull complete
11775a3d792d: Pull complete
13fdd17462ac: Pull complete
2092995a1e54: Pull complete
Digest: sha256:409501d73062ab508930eab827fcb19d7d3f7e9bbe63bc6d587114c6af4bee12
Status: Downloaded newer image for tomcat:latest
```

通过此命令，我们将名为`tomcat`的镜像`pull`到了本地的Docker中。

### 查看Docker中的镜像

此时，我们要查看镜像是否已经获取成功。

输入命令：

```
adler@A ~/docker/tomcat: docker images
REPOSITORY                        TAG                 IMAGE ID            CREATED             SIZE
tomcat                            latest              5a069ba3df4d        14 hours ago        465MB
```

### 启动！

现在，我们可以启动镜像了。

输入命令：

```
adler@A ~/docker/tomcat: docker run -itd -p 8080:8080 --name tomcat tomcat:latest
```

参数解释：

`run` 用于运行镜像为容器
```
-itd:
-t 让Docker分配一个伪终端并绑定到容器的标准输入上
-i 则让容器的标准输入保持打开
-d 在后台运行，并返回一个容器ID
```
`-p 8080:8080` 将容器中的8080端口映射到外部的8080端口
`--name tomcat` 设置容器名称为tomcat
`tomcat:latest` 镜像名:版本，输入latest则自动匹配最新的版本。

### 访问测试

现在，访问[http://localhost:8080/](http://localhost:8080/)，你应该可以访问到Tomcat的默认页了。

![image.png](https://pic.stackoverflow.wiki/uploadImages/9e26fc10-a9b7-4eb0-b038-27ab02202ccb.png)

# 编辑修改Tomcat

刚才我们成功启动了Tomcat镜像，下面我们将对该容器中的文件进行添加、修改和删除的操作。

由于**容器在关闭后里面写入的数据会丢失**，而**容器来自于镜像**，当每次我们运行`run`时，Docker会**将指定镜像实例化为一个容器**。所以如果我们修改**镜像**的内容，那么更改就会被保存了。

### 修改容器

我们要先基于容器修改完成，然后将修改覆盖到镜像。
先查看正在运行中的容器，并记住容器ID：

```
 adler@A ~/docker/tomcat: docker container ls
CONTAINER ID        IMAGE                             COMMAND                  CREATED             STATUS              PORTS                    NAMES
79f9a1ed1578        tomcat:latest                     "catalina.sh run"        44 seconds ago      Up 44 seconds       0.0.0.0:8080->8080/tcp   tomca1tw
d92264056899        vulnerable-node_vulnerable_node   "/app/start.sh"          6 days ago          Up 8 hours          0.0.0.0:3000->3000/tcp   vulnerable-node_vulnerable_node_1
74870fdf32ac        vulnerable-node_postgres_db       "docker-entrypoint.s…"   6 days ago          Up 8 hours          0.0.0.0:5432->5432/tcp   vulnerable-node_postgres_db_1
```

我们使用`docker exec`来调用出该容器的Bash终端：

```
adler@A ~/docker/tomcat: docker exec -it 79f9 bash
root@79f9a1ed1578:/usr/local/tomcat# echo "HelloWorld!" > webapps/ROOT/index.jsp
```

`79f9`是上方查询的容器ID的前四位，我们不需要输入完整的容器ID就可以对容器进行操作。

上面，我们将`index.jsp`的内容覆盖为了`HelloWorld!`，访问页面，验证页面内容更改成功。

![image.png](https://pic.stackoverflow.wiki/uploadImages/90ca830b-c7ef-4692-ba0e-efddf4966716.png)

### 更新镜像

然后，将我们修改后的容器提交到镜像中：

```
adler@A ~/docker/tomcat: docker commit 79f9 tomcat:latest
```

我们将容器`79f9`的更改`commit`提交到了`tomcat`镜像的`latest`版本中。

### 重启容器测试

现在，尝试使用`docker container stop [容器ID]`停止容器，并重新使用`docker run`来部署一个新的容器。打开测试，更改已经生效。

# 后语

此时，你已经能进行Docker的各种基础操作了。
下一章我们将讲述如何自己制作一个Tomcat的Docker镜像。

[点我跳转至下一章](https://www.stackoverflow.wiki/blog/articles/2019/04/14/1555205953430.html)
