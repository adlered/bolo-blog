title: 大白话之Docker(叁)：制作一个运行Tomcat服务端的Docker镜像
date: '2019-04-14 09:39:13'
updated: '2019-12-09 09:46:46'
tags: [大白话, Docker]
permalink: /articles/2019/04/14/1555205953430.html
---
# 前言

### [如没看过上一章，请点我跳转](https://www.stackoverflow.wiki/blog/articles/2019/03/19/1553004723789.html)

上一章我们使用Tomcat镜像搭建了一个WEB服务端。
本章，我们将从零开始搭建一个Tomcat服务端。大体需要以下步骤：

1. 在容器中安装一个系统（我使用Ubuntu）
2. 在容器中安装JDK并配置环境变量以运行Tomcat
3. 在容器中拷贝Tomcat

既然目标已经明确，那么我们就开始吧。

# 初始化项目

### 下载文件

在项目开始之前，我们需要下载所需的文件：

[JDK 1.8](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
[Tomcat 9](https://tomcat.apache.org/download-90.cgi)

### 解压文件

将JDK和Tomcat的压缩包解压，并新建一个文件夹用于存放该镜像所需的文件，把解压后的文件夹拷贝到该文件夹中。

```
adler@localhost ~/dockerTomcat: tar -zxvf jdk-8u201-linux-x64.tar.gz
adler@localhost ~/dockerTomcat: tar -zxvf apache-tomcat-9.0.13.tar.gz
adler@localhost ~/dockerTomcat: ls
apache-tomcat-9.0.13 jdk1.8.0_201
```

# Dockerfile

`Dockerfile`就像一个脚本语言，它用于告知Docker如何制作一个镜像。让我们在Docker目录中新建一个`Dockerfile`文件，编辑内容：

```
FROM ubuntu
MAINTAINER AdlerED
ENV REFRESHED_AT 2019-04-14

WORKDIR /usr
RUN mkdir jdk
RUN mkdir tomcat
ADD jdk1.8.0_201 /usr/jdk
ADD apache-tomcat-9.0.13 /usr/tomcat

ENV JAVA_HOME=/usr/jdk
ENV JRE_HOME=$JAVA_HOME/jre
ENV CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib:$CLASSPATH
ENV PATH=/sbin:$JAVA_HOME/bin:$PATH

EXPOSE 8080
ENTRYPOINT ["/usr/tomcat/bin/catalina.sh","run"]
```

看不懂？没关系，这里有常用命令解释：

```
FROM 使用镜像
RUN 执行命令
ADD 添加文件
COPY 拷贝文件
CMD 执行命令
EXPOSE 执行命令
WORKDIR 指定路径
MAINTAINER 维护者
ENV 设定环境变量
USER 指定路径
VOLUME 逻辑卷挂载点
```

这样，我们就在Ubuntu的基础上安装了JDK并配置好了环境。

# 制作镜像

保存`Dockerfile`。下面让我们构造一个Docker镜像：

`注意：命令中有一个"."，表示当前目录下的所有文件/文件夹。`

```
adler@localhost ~/dockerTomcat: docker build -t tom1 .
Sending build context to Docker daemon    465MB
Step 1/14 : FROM ubuntu
latest: Pulling from library/ubuntu
898c46f3b1a1: Already exists
63366dfa0a50: Already exists
041d4cd74a92: Already exists
6e1bee0f8701: Already exists
Digest: sha256:017eef0b616011647b269b5c65826e2e2ebddbe5d1f8c1e56b3599fb14fabec8
Status: Downloaded newer image for ubuntu:latest
 ---> 94e814e2efa8
Step 2/14 : MAINTAINER AdlerED
 ---> Running in 0d8881a48673
Removing intermediate container 0d8881a48673
 ---> 096a71fce35c
Step 3/14 : ENV REFRESHED_AT 2019-04-14
 ---> Running in cc70cde8bbdf
Removing intermediate container cc70cde8bbdf
 ---> 5e729baf8ba6
Step 4/14 : WORKDIR /usr
 ---> Running in ffafbb0c2f39
Removing intermediate container ffafbb0c2f39
 ---> 5c67d2c834b8
Step 5/14 : RUN mkdir jdk
 ---> Running in 456ba09c5f78
Removing intermediate container 456ba09c5f78
 ---> 4b20a82e75b2
Step 6/14 : RUN mkdir tomcat
 ---> Running in 4e37fa2c7f1e
Removing intermediate container 4e37fa2c7f1e
 ---> 36be7992366e
Step 7/14 : ADD jdk1.8.0_201 /usr/jdk
 ---> b73582ceb345
Step 8/14 : ADD apache-tomcat-9.0.13 /usr/tomcat
 ---> de37ef37b5f0
Step 9/14 : ENV JAVA_HOME=/usr/jdk
 ---> Running in 2fb661484354
Removing intermediate container 2fb661484354
 ---> 65486f651010
Step 10/14 : ENV JRE_HOME=$JAVA_HOME/jre
 ---> Running in 589b25aee5c9
Removing intermediate container 589b25aee5c9
 ---> 21ff9fc63c15
Step 11/14 : ENV CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib:$CLASSPATH
 ---> Running in 0041fb914b69
Removing intermediate container 0041fb914b69
 ---> d4e69f027c43
Step 12/14 : ENV PATH=/sbin:$JAVA_HOME/bin:$PATH
 ---> Running in dca277cebf53
Removing intermediate container dca277cebf53
 ---> 1d17efbfa7f7
Step 13/14 : EXPOSE 8080
 ---> Running in 3c34d45b2b12
Removing intermediate container 3c34d45b2b12
 ---> cb23d57bbad3
Step 14/14 : ENTRYPOINT ["/usr/tomcat/bin/catalina.sh","run"]
 ---> Running in a568509006bf
Removing intermediate container a568509006bf
 ---> c3f64777810c
Successfully built c3f64777810c
Successfully tagged tom1:latest
```

这样，我们就成功将Tomcat制作为了一个镜像。让我们运行它：

```
adler@localhost ~/dockerTomcat: docker run -it -p 8080:8080 tom1
```

不出意外的话，访问`http://localhost:8080`，你应该可以看到Tomcat的默认页了。

# 后语

此时，我们成功搭建了一个Tomcat的运行环境，它基于Ubuntu。至此，你已经成功入门了Docker！
