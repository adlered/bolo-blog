title: 'Spring: java.lang.NoSuchMethodError: clearCache | ClassNotFoundException |
  Error during artifact deployment 思路及解决办法'
date: '2019-05-04 16:21:48'
updated: '2019-12-09 09:44:20'
tags: [JavaWeb, SpringMVC, Debug, Tomcat]
permalink: /articles/2019/05/04/1556958108376.html
---
# 前言

一如既往的今天，打算打开WEB项目一如既往地修（写）BUG。就在我运行的时候，弹出了错误：

```
java.lang.NoSuchMethodError: org.springframework.core.ResolvableType.clearCache()
	at org.springframework.context.support.AbstractApplicationContext.resetCommonCaches(AbstractApplicationContext.java:873)
	at org.springframework.context.support.AbstractApplicationContext.refresh(AbstractApplicationContext.java:559)
	at org.springframework.web.context.ContextLoader.configureAndRefreshWebApplicationContext(ContextLoader.java:403)
	at org.springframework.web.context.ContextLoader.initWebApplicationContext(ContextLoader.java:306)
	at org.springframework.web.context.ContextLoaderListener.contextInitialized(ContextLoaderListener.java:106)
	at org.apache.catalina.core.StandardContext.listenerStart(StandardContext.java:4853)
	at org.apache.catalina.core.StandardContext.startInternal(StandardContext.java:5314)
	at org.apache.catalina.util.LifecycleBase.start(LifecycleBase.java:145)
	at org.apache.catalina.core.ContainerBase.addChildInternal(ContainerBase.java:753)
	at org.apache.catalina.core.ContainerBase.addChild(ContainerBase.java:729)
	at org.apache.catalina.core.StandardHost.addChild(StandardHost.java:717)
	at org.apache.catalina.startup.HostConfig.deployDirectory(HostConfig.java:1092)
	at org.apache.catalina.startup.HostConfig$DeployDirectory.run(HostConfig.java:1834)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:745)
```

```
严重: Error configuring application listener of class org.springframework.web.util.Log4jConfigListener
java.lang.ClassNotFoundException: org.springframework.web.util.Log4jConfigListener
	at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1702)
	at org.apache.catalina.loader.WebappClassLoader.loadClass(WebappClassLoader.java:1547)
	at org.apache.catalina.core.DefaultInstanceManager.loadClass(DefaultInstanceManager.java:532)
	at org.apache.catalina.core.DefaultInstanceManager.loadClassMaybePrivileged(DefaultInstanceManager.java:514)
	at org.apache.catalina.core.DefaultInstanceManager.newInstance(DefaultInstanceManager.java:142)
	at org.apache.catalina.core.StandardContext.listenerStart(StandardContext.java:4854)
	at org.apache.catalina.core.StandardContext.startInternal(StandardContext.java:5434)
	at org.apache.catalina.util.LifecycleBase.start(LifecycleBase.java:150)
	at org.apache.catalina.core.ContainerBase$StartChild.call(ContainerBase.java:1559)
	at org.apache.catalina.core.ContainerBase$StartChild.call(ContainerBase.java:1549)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:745)
```

马鸭，昨天还能完完整整的运行，今天咋就废了？

# 解决思路

小提示：如果你使用IDEA，Tomcat提示Error during artifact deployment，你可以在**Tomcat Localhost Log**查看错误日志：

![8.png](https://pic.stackoverflow.wiki/uploadImages/abc439c1-a31d-454f-8312-2fa8f56e226c.png)

在各种翻找和思考后，我尝试了以下几种办法：

> 下方都有可能是导致出现该问题的解决方案，每个解决方案不能保证解决问题，但我建议在**备份后**多做尝试。

## 1）代码出错

出现问题可能是由于你的注解使用不遵循语法导致的，而IDE无法检测部分注解的正确性。

> 引用自[https://blog.csdn.net/x_iya/article/details/54234665](https://blog.csdn.net/x_iya/article/details/54234665)
```
@WebServlet(name = "testServlet", urlPatterns = {"test.do"})
```
上面这段代码的`urlPatterns`赋值不符合要求，应修改为：
```
@WebServlet(name = "testServlet", urlPatterns = "test.do")
```

**不过**在我与上一正常比对后确认，我的语法符合要求。

## 2）Rebuild

在IDEA中，默认不会将所有文件重新编译一次，而是只编译检测到修改的文件。但有时也会出现BUG，尝试`Build` - `Rebuild Project`来解决。

![](https://pic.stackoverflow.wiki/uploadImages/6ff2c31a-c2fd-4635-8e55-f1a14f8beb65.png)

在尝试后，也没有解决我的问题。

## 3）web.xml

检查`WEB-INF` - `web.xml`文件的`contextConfigLocation`设置，它用于在拦截器中定义配置文件的位置。

![](https://pic.stackoverflow.wiki/uploadImages/425d30ae-7105-485a-a21e-40ed84833003.png)

1. 检查`param-value`指向的Spring配置文件是否正确
2. 如果没有此配置项，添加一个

如果你不知道应该指向哪个文件，查找你的项目中是否有`contextConfig.xml`，或内容类似下图中的文件：

![](https://pic.stackoverflow.wiki/uploadImages/5a33b50d-a5cb-4bd7-8099-a45fa8068b36.png)

经检查，我的配置没有问题。

## 4）配置Artifacts

如果你使用的IDE是IDEA，按`CTRL+ALT+SHIFT+S`进入`Project Structure`设置，选择左侧`Artifacts`，在右侧选择你Tomcat部署的项目：

![](https://pic.stackoverflow.wiki/uploadImages/2ee4c477-5df4-4ca3-8eb7-cfed64a28866.png)

在`Available Elements`下方，右键你的项目并选择`Put into Output Root`。

（绝望）还是无法正常启动。

## 5）Spring版本

由于提示了`NoSuchMethodError: clearCache`，在经过查阅后得知`clearCache()`是`Spring 4.2+`版本才有的方法。如果你使用了Maven，可以通过修改pom.xml来修改Spring的版本：

修改（如果不存在则添加）配置：

```
<spring.version>4.2.3.RELEASE</spring.version>
```

重新Build项目。

在修改版本后，我的Spring便换了一个报错：

```
Error during artifact deployment. See server log for details.
```

于是查看日志（IDEA中选择Tomcat Localhost Log选项卡），发现错误原因是：

```
java.lang.ClassNotFoundException
```

很明显，有Jar包并没有被Tomcat所识别，也就是说，Maven在将所有Jar包复制到Tomcat的Lib中时，出现了**漏网之鱼**。

## 6）Maven：重新导入

既然出现了漏网之鱼，就把Maven中的所有依赖重新导入试试。
在IDEA中，右键`pom.xml`文件，选择`Maven` -> `Reimport`即可。

![](https://pic.stackoverflow.wiki/uploadImages/cff88fd1-d506-4d97-a91d-41c96a37c17b.png)

## 7）配置Tomcat

由于刚刚我们修改了`Artifact`，我们就需要将`Artiface`的项目部署重新绑定到`Tomcat`中。
在IDEA中，点击右上角的Tomcat项目，选择`Edit Configuration`。

![](https://pic.stackoverflow.wiki/uploadImages/86196c45-7be7-4a10-be5b-1c5fb4578007.png)

在`Deployment`中，选中第一个窗口中的内容，并点击下方`减号`，然后再点击`加号`，重新添加你刚刚修改的`Artifact`项目部署。

![](https://pic.stackoverflow.wiki/uploadImages/2d6113d8-1cad-44db-b6b0-16235acd8264.png)

请注意：`Application context`选项，会在你修改部署文件后自动变更为项目名为目录，我建议将其修改为`/`，以根目录来访问网站目录。

# 后语

通过各种尝试，我发现在使用4、6、7三种方法后，我的问题终于得到了解决。在此建议，在备份项目后，尝试每一种方法。祝你修复成功！（我先去自闭了，我相信你会来一起自闭的......）

> 牢骚：啥也没动就这样了，折腾了一天...... 心累。
把所有的解决方案都尝试复现并记录下来了，希望能帮到现在满头大汉（误）的你。
由于是问题复现，所以记录可能不完整，如有问题可以在评论区交流~
