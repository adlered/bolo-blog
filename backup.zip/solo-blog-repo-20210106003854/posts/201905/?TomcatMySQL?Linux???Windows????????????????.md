title: 将Tomcat、MySQL从Linux迁移到Windows的心路历程（干货）：令人恐惧的字符编码
date: '2019-05-03 18:32:29'
updated: '2019-12-09 09:45:39'
tags: [Tomcat, Linux, Windows, UTF-8]
permalink: /articles/2019/05/03/1556879549795.html
---
<h1>前言</h1>
近日打算对服务端进行进一步的解耦，便购入了云数据库服务，将数据库独立，使得Tomcat主机独立运行，提高安全性和便利性。<br />
心血来潮，想将服务器重装为Windows，便有了下面的一系列文章：
<h1>迁移MySQL</h1>
平时我都是使用Navicat对MySQL进行管理。在备份的第一时间我便想到了使用Navicat进行数据的迁移。

<h2>Dump SQL File</h2>
<img height="676" src="https://pic.stackoverflow.wiki/uploadImages/ea64a13e-fe7d-4e17-acc8-f52df390f4dc.png" width="942" /><br />
<br />
右键指定的数据库，选择<strong>Dump SQL File</strong> -&gt; <strong>Structure + Data</strong>就可以将选定数据库全部的结构、参数、表、键值保存到一个文件中，我将其输出到桌面以便恢复。<br />
<br />
<img height="318" src="https://pic.stackoverflow.wiki/uploadImages/b22280fa-53a7-446c-934a-9437e30a2210.png" width="694" />
<h2>Execute SQL File</h2>
登录到新的数据库中，并建立一个名称相同的数据库。右键该数据库，选中<strong>Execute SQL File</strong>：<br />
<br />
<img height="458" src="https://pic.stackoverflow.wiki/uploadImages/acb69b3f-6565-4146-98a0-1ec33e5a26cc.png" width="654" /><br />
<br />
<img src="https://pic.stackoverflow.wiki/uploadImages/83ff8b26-f6b2-4e0a-b863-2f28733418e2.png" />
<h1>为什么要迁移</h1>
比对Windows和Linux的区别，对我而言：

<h2>Linux（Ubuntu 16.04）</h2>

<h3>优点</h3>

<ol>
	<li>占用内存小</li>
	<li>Terminal用起来太爽</li>
	<li>开源</li>
	<li>安装工具方便（apt）</li>
	<li>......</li>
</ol>

<h3>不足</h3>

<ol>
	<li>不知道，别问我</li>
</ol>

<h2>Windows （Windows Server 2016）</h2>

<h3>优点</h3>

<ol>
	<li>桌面环境比较成熟</li>
	<li>文件权限划分清晰严谨</li>
	<li>图形界面进行编辑（学不会Vim）、服务安装配置比较快捷</li>
        <li>能挂QQ成长值（？！）</li>
</ol>

<h3>不足</h3>

<ol>
	<li>内存占用太高，开机就2G</li>
	<li>......</li>
</ol>

<h1>迁移前我做的规划</h1>

<ol>
	<li>将Tomcat服务端打包，备份到本地</li>
	<li>安装Java并配置环境变量</li>
	<li>用IIS配置FTP服务</li>
	<li>将Tomcat服务端上传，并运行测试</li>
	<li>配置防火墙，禁止一大堆自带的服务监听端口</li>
</ol>

<h1>我遇到的问题</h1>

<h2>1. 控制台中文乱码</h2>
遇到这个问题的时候，我还是不慌的，在我的意料之内。<br />
在查找资料后，我找到了解决办法：<br />
在<strong>conf/logging.properties</strong>文件中，添加下面一行（先检查是否已经存在，如果已经存在直接修改即可）：

```
java.util.logging.ConsoleHandler.encoding = GBK

```
<p><img height="426" src="https://pic.stackoverflow.wiki/uploadImages/66b0883b-732b-4228-a28e-19b03bc064d0.png" width="708" /></p>

<p>这是因为Windows的控制台编码为<strong>GBK</strong>，而Linux的终端编码一般为<strong>UTF-8</strong>而导致的。</p>

<h2>2. ​​​HTML中文乱码</h2>
这可真是令人手忙脚乱了... JSP和Servlet都是正常的，但HTML的中文却是乱码。排除法：<br />
&radic; HTML头部设置了<strong>&lt;meta charset=&quot;utf-8&quot;/&gt;</strong><br />
&radic; HTML源文件编码经检测为UTF-8<br />
&radic; web.xml拦截器编码设置为UTF-8<br />
? 问题可能出在Tomcat的配置<br />
<br />
&mdash;&mdash; 再次经过几经查找，我找到了两种解决方法：
<h3>方法一：server.xml</h3>
编辑conf/server.xml文件，在<strong>Connector</strong>后边追加参数<strong>URIEncoding=&quot;UTF-8&quot;</strong><br />
<img height="40" src="https://pic.stackoverflow.wiki/uploadImages/90859cd1-ee58-4236-b3a7-071ee7ad5bc7.png" width="618" /><br />
由于我开启了SSL，所以在<strong>port</strong>为<b>443</b>的后方加入。如果你没有使用HTTPS而只是使用了HTTP，那么找到<strong>port</strong>为<strong>80</strong>的后方加入即可。

<h3>方法二：catalina.sh</h3>
编辑bin/catalina.sh文件：<br />
<img height="54" src="https://pic.stackoverflow.wiki/uploadImages/b2d3cef0-465f-476f-a92c-9102f14aca31.png" width="1106" /><br />
找到<strong>JAVA_OPTS</strong>并追加参数：

```
-Dfile.encoding=utf-8
```
通过这条参数，我们可以从根源（JVM）处告诉Tomcat，要以UTF-8的编码来读取文件。<br />
最后，通过方法二（推荐都使用）解决了HTML中文乱码的问题。
<h2>3. APR模式不可用</h2>
经常使用Tomcat的小伙伴可能知道<strong>APR</strong>模式。

<h3>Tomcat的三种模式</h3>

<table border="1" cellpadding="1" cellspacing="1" style="width:500px;">
	<tbody>
		<tr>
			<td>模式</td>
			<td>描述</td>
			<td>性能</td>
		</tr>
		<tr>
			<td>BIO</td>
			<td>Blocking I/O 阻塞式I/O操作，表示Tomcat使用的是传统的Java I/O操作。</td>
			<td>低</td>
		</tr>
		<tr>
			<td>NIO</td>
			<td>Non-Blocking I/O&nbsp;基于缓冲区，并能提供非阻塞I/O操作的Java API。</td>
			<td>中</td>
		</tr>
		<tr>
			<td>APR</td>
			<td>Tomcat将以JNI的形式调用Apache HTTP服务器的核心动态链接库来处理文件读取或网络传输操作，从而大大地提高Tomcat对静态文件的处理性能。</td>
			<td>高</td>
		</tr>
	</tbody>
</table>
在Linux，我一直使用APR模式来运行Tomcat服务端，但这次有些不对劲儿。

<h3>JAVA_OPTS可能与APR模式冲突</h3>
由于APR模式需要安装额外的扩展，我便安装并进行了测试，但并没有效果。<br />
在这之后，我尝试了：
<ol>
	<li>使用安装版Tomcat并勾选APR扩展</li>
	<li>重新生成配置文件</li>
	<li>重新生成并导入域名SSL证书</li>
	<li>查找可能导致冲突的配置</li>
</ol>
最终的一个现象：<br />
<strong>一旦我开启APR模式，HTTPS就无法访问。</strong><br />
在一个下午的苦苦挣扎后，我找到了问题所在：
<blockquote>
<p>一旦为<strong>JAVA_OPTS</strong>添加参数<strong>-Dfile.encoding=utf-8</strong>，APR模式就无法正常工作。</p>
</blockquote>

<h2>为什么不直接将所有文件转码为GBK？</h2>
其实我本可以直接将所有的页面文件转码为GBK（Windows的默认编码）从而直接防止上述所有情况的发生，但<strong>过程复杂，且一旦需要迁移回Linux非常繁琐</strong>。<br />
所以最后，我放弃了APR，使用无需额外扩展及配置的NIO模式：<br />
编辑<strong>conf/server.xml</strong>：<br />
<img height="114" src="https://pic.stackoverflow.wiki/uploadImages/8193c93e-c8ac-4b3f-b123-77ae00bff089.png" width="714" /><br />
修改<strong>protocol</strong>的参数为
```
org.apache.coyote.http11.Http11NioProtocol

```
<h1>后语</h1>
总的来说，除了在文件编码方面略有困难之外，在<strong>提前做好充足功课</strong>之后还是能够迁移成功的。<br />
生命在于折腾。<br />
（如果事事都能像自己预想的那样运行，谁还愿意瞎折腾呢？）
