title: 实例带你学会简单的Java Thread多线程
date: '2019-03-17 16:20:04'
updated: '2019-12-09 09:52:02'
tags: [Java, Coding]
permalink: /articles/2019/03/15/1552618569953.html
---
# 前言

在学习本教程之前，你对以下知识有所了解：
* Java的类、方法、变量
* extend的用法和用处
* Java实例化

本篇教程难度：★☆☆☆☆

多线程是计算机的灵魂，目的是为了`同时做很多事情`。

你可能不知道，早期的操作系统一次只能运行一个程序，如果要切换程序，必须关闭当前程序，早期的iPhone便是如此。

# 拷贝

废话少说，在你的IDE中新建一个Java项目或类用于存放本次多线程的代码。
我建议将类命名为：`ThreadDemo`，这样在拷贝代码后不需要修改类名。

复制下方代码到你的类中：

```
import java.text.SimpleDateFormat;
import java.util.Date;

public class ThreadDemo {
    public static void main(String[] args) {
        //实例化当前类
        ThreadDemo threadDemo = new ThreadDemo();
        //调用动态类
        threadDemo.run();
    }
    
    public void run() {
        ThreadTest1 threadTest1 = new ThreadTest1();
        threadTest1.run();
        threadTest1.run();
        threadTest1.run();
        threadTest1.run();
        threadTest1.run();
    }
}

/**
 * 线程1
 */
class ThreadTest1 extends Thread {
    @Override
    public void run() {
        //获取当前时间
        Date day = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy年MM月dd日 HH点mm分ss秒SSS毫秒");
        //打印当前时间
        System.out.println("现在是：" + df.format(day));
    }
}
```

## 让我们分开理解

### 线程类

```
class ThreadTest1 extends Thread {
    @Override
    public void run() {
        //获取当前时间
        Date day = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy年MM月dd日 HH点mm分ss秒SSS毫秒");
        //打印当前时间
        System.out.println("现在是：" + df.format(day));
    }
}
```

该类继承了`Thread`多线程类，所以这个类就支持多线程了~
该类中的方法：

```
    @Override
    public void run() {
        //获取当前时间
        Date day = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy年MM月dd日 HH点mm分ss秒SSS毫秒");
        //打印当前时间
        System.out.println("现在是：" + df.format(day));
    }
```

下方知识如果不理解可以**直接跳过**，在未来的学习中你自然会懂：
`@Override `在本文表示对extend的`Thread`类的`run()`方法进行`重写`；
`run()`方法是线程运行的方法，其中的方法完全由你来定义；

**你需要知道的**：
你可以自由修改`run()`方法里面所有的内容，它将在接收到执行命令时被执行。

### 执行方法

```
    public static void main(String[] args) {
        //实例化当前类
        ThreadDemo threadDemo = new ThreadDemo();
        //调用动态类
        threadDemo.run();
    }

    public void run() {
        ThreadTest1 threadTest1 = new ThreadTest1();
        threadTest1.run();
        threadTest1.run();
        threadTest1.run();
        threadTest1.run();
        threadTest1.run();
    }
```

首先主方法里面的代码是用来执行`run()`方法的。这么写的原因是因为主方法是`静态方法`，使其调用一个`动态方法`的原因是动态方法更加灵活，因此你可以**无视**主方法，直接阅读`run()`方法。
**注意：此处的`run()`方法和`ThreadTest`类中的`run()`方法不是同一个方法。**

继续看：

```
        ThreadTest1 threadTest1 = new ThreadTest1();
        threadTest1.run();
        threadTest1.run();
        threadTest1.run();
        threadTest1.run();
        threadTest1.run();
```

在该方法中，我们将`ThreadTest`类进行**实例化**，这样我们就能执行这个线程了。并且我们将该线程执行了**5**次。

### 运行!

现在，运行主方法，你会得到如下结果：

```
现在是：2019年03月16日 12点21分20秒685毫秒
现在是：2019年03月16日 12点21分20秒743毫秒
现在是：2019年03月16日 12点21分20秒744毫秒
现在是：2019年03月16日 12点21分20秒744毫秒
现在是：2019年03月16日 12点21分20秒744毫秒
```

可以看到，我们成功执行了五个线程，并得到了预期的运行结果。

#### 疑问

？ 为什么多线程执行后的结果，毫秒不相同？
！ 仔细看你会发现，这五次的多线程执行后的时间是`由小到大`的，所以线程被提交是有`间隔时间`并且是被`顺序执行`的。

# 后语

这是多线程的基本使用，如果需要继续了解线程池的知识，[请点这里](https://www.stackoverflow.wiki/blog/articles/2019/03/13/1552488916927.html)。
