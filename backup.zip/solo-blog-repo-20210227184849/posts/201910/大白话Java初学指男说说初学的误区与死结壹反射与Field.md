title: 大白话 | Java初学指♂男：“说说初学的误区与死结”（ 壹 | 反射与Field ）
date: '2019-10-14 21:52:48'
updated: '2019-12-09 17:51:52'
tags: [初学指男, 大白话]
permalink: /articles/2019/10/14/1571061168019.html
---
![](https://ftp.stackoverflow.wiki/zdV_201905267591471845036998768.jpg) 

# 思考

通常，我们这么给变量赋值：

```
String name = "XiaoMing";
name = "DaMing";
```

那么假如，我们**不允许直接给name这个变量赋值**，但我们提供**与该变量名相同的字符串**：

```
String name = "XiaoMing";

// variable 中指定了要修改的变量
String variable = "name";

// 将 variable 中指定的变量修改为 value 的值
String value = "DaMing";

// 不允许使用以下方法直接给 name 赋值：
// name = value;
// name = "DaMing";
// 要求最终， name 的值为 DaMing
```

题目要求：

1. 根据`variable`变量中的字符串`name`，找到**和字符串名字相同的变量**
2. 将`variable`字符串中指定**变量**的值修改为`DaMing`
3. 必须依靠字符串来修改该变量的值，而**不是直接赋值**
4. 最终，变量`name`的值应该是`DaMing`，而**不应该**去修改变量`variable`的值

# 实例

想好了吗？让我们来看看下方的题解：

```
public class Main {
    // 定义 name 为静态变量，在启动时就被定义
    public static String name = "XiaoMing";

    public void Test() {
        try {

            System.out.println("修改前，name的值为：" + name);

            String variable = "name";
            String value = "DaMing";

            // 获取 name 所在 Main 类的 Class 反射
            Class clazz = Main.class;

            // 通过getDeclaredField(String 变量名) 可以获得该类中指定变量的操作权
            // 而 Field 就可以提供对变量的操作
            Field field = clazz.getDeclaredField(variable);
	    // 也可以写为：
	    // Field field = clazz.getDeclaredField("name");

            // 使用 field.set(Class反射类, 值) 可以将该变量修改为指定值
            field.set(clazz, value);
            // 也可以写为：
            // field.set(clazz, "DaMing");

            System.out.println("修改后，name的值为：" + name);

        } catch (Exception e) {}
    }

    public static void main(String[] args) {
        new Main().Test();
    }

}
```

返回结果：

```
修改前，name的值为：XiaoMing
修改后，name的值为：DaMing
```

### 解析

```
public static String name = "XiaoMing";
```

`name`是一个`公共的` `静态变量`，它的初始值是`XiaoMing`。

```
String variable = "name";
String value = "DaMing";
```

要将`variable`中指定的变量名的值修改为`value`的值。

```
Class clazz = Main.class;
```

`Main`是`name`变量所属的类，调用`XXX.class`可以返回一个`Class`反射类，但这里的`Class`反射类是完整的，我们可以访问其中所有的变量和方法，进行任意修改。

```
Field field = clazz.getDeclaredField(variable);
```

`Class.getDeclaredField(变量名)`会返回一个`Field`类，这个`Field`类可以对我们指定的变量进行读写。

```
field.set(clazz, value);
```

`field.set(反射类, 值)` 可以将反射类之中，符合该`field`变量的变量值，修改为`value`中指定的值。

`field`中存储了一个独立的变量，和`Class`没有关联。
只要任意类中含有和这个`field`中相同的变量，我们就可以直接使用`field.set(反射类, 值)`对其进行修改。

# 实战

### 实战演练

#### 题目

![屏幕快照 2019-10-15 下午11.15.55.png](https://pic.stackoverflow.wiki/uploadImages/be02359d-db25-4290-9299-643c4f3b33a0.png)

我们要在`Main`类中修改在`Variable`类中的`name`变量。

打开你的IDE，试一试吧。

#### 答案

![屏幕快照 2019-10-15 下午11.18.20.png](https://pic.stackoverflow.wiki/uploadImages/69c2ae21-d118-4efa-b24f-d91629d7a181.png)
