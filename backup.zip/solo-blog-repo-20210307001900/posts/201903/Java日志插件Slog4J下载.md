title: Java日志插件-Slog4J下载
date: '2019-03-28 16:36:06'
updated: '2019-12-09 09:48:06'
tags: [Slog4J]
permalink: /articles/2019/03/28/1553762166613.html
---
# 下载地址
# Direct download link

### <a href="/Slog4J_1_0_3.jar">点我下载</a>
### <a href="/Slog4J_1_0_3.jar">Click me</a>

# 更新日志
1.0.3 - 修复了数据库中文乱码的问题，增加了文件输出颜色的选项
1.0.2 - 修复了已知问题
1.0.1 - 修复了本地文件输出中文乱码的问题

如使用中出现问题，欢迎评论反馈！

[GitHub页面](https://github.com/AdlerED/Slog4J)
