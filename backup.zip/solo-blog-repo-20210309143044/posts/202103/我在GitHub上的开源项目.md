title: 我在 GitHub 上的开源项目
date: '2021-03-08 16:47:33'
updated: '2021-03-08 16:47:33'
tags: [开源, GitHub]
permalink: /github
---
### 1. [baidu-netdisk-downloaderx](https://github.com/88250/baidu-netdisk-downloaderx) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[⭐️`484`](https://github.com/88250/baidu-netdisk-downloaderx/stargazers "收藏数")&nbsp;&nbsp;[🖖`146`](https://github.com/88250/baidu-netdisk-downloaderx/network/members "分叉数")</span>

⚡️ 一款图形界面的百度网盘不限速下载器，支持 Windows、Linux 和 Mac。已于 2020 年 4 月 15 日正式停用，源码仅用于程序员交流学习，细节请查看：关于停用 BND 的说明 https://ld246.com/article/1586956316578



---

### 2. [liandi](https://github.com/88250/liandi) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`354`](https://github.com/88250/liandi/stargazers "收藏数")&nbsp;&nbsp;[🖖`75`](https://github.com/88250/liandi/network/members "分叉数")&nbsp;&nbsp;[🏠`https://b3log.org/siyuan`](https://b3log.org/siyuan "项目主页")</span>

📕 一款桌面端的 Markdown 块级引用和双向链接笔记应用，支持 Windows、Mac 和 Linux。A desktop Markdown Block-Reference and Bidirectional-Link note-taking application, supports Windows, Mac and Linux. 



---

### 3. [lute](https://github.com/88250/lute) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`213`](https://github.com/88250/lute/stargazers "收藏数")&nbsp;&nbsp;[🖖`43`](https://github.com/88250/lute/network/members "分叉数")&nbsp;&nbsp;[🏠`https://ld246.com/tag/lute`](https://ld246.com/tag/lute "项目主页")</span>

🎼 一款对中文语境优化的 Markdown 引擎，支持 Go 和 JavaScript。A structured Markdown engine that supports Go and JavaScript. 



---

### 4. [city-geo](https://github.com/88250/city-geo) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`196`](https://github.com/88250/city-geo/stargazers "收藏数")&nbsp;&nbsp;[🖖`65`](https://github.com/88250/city-geo/network/members "分叉数")&nbsp;&nbsp;[🏠`https://ld246.com`](https://ld246.com "项目主页")</span>

🌄 中国城市经纬度数据。



---

### 5. [awesome-seeds](https://github.com/88250/awesome-seeds) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`70`](https://github.com/88250/awesome-seeds/stargazers "收藏数")&nbsp;&nbsp;[🖖`19`](https://github.com/88250/awesome-seeds/network/members "分叉数")</span>

🌱 发现新鲜有趣的小型开源项目，欢迎投稿！



---

### 6. [gulu](https://github.com/88250/gulu) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`44`](https://github.com/88250/gulu/stargazers "收藏数")&nbsp;&nbsp;[🖖`17`](https://github.com/88250/gulu/network/members "分叉数")&nbsp;&nbsp;[🏠`https://ld246.com/tag/gulu`](https://ld246.com/tag/gulu "项目主页")</span>

⭕ Go 语言常用工具库，这个轱辘还算圆！



---

### 7. [latke](https://github.com/88250/latke) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`35`](https://github.com/88250/latke/stargazers "收藏数")&nbsp;&nbsp;[🖖`21`](https://github.com/88250/latke/network/members "分叉数")&nbsp;&nbsp;[🏠`https://ld246.com/tag/latke`](https://ld246.com/tag/latke "项目主页")</span>

🌀 一款以 JSON 为主的 Java Web 框架。A Java Web framework based on JSON. 



---

### 8. [lute-docx](https://github.com/88250/lute-docx) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`15`](https://github.com/88250/lute-docx/stargazers "收藏数")&nbsp;&nbsp;[🖖`5`](https://github.com/88250/lute-docx/network/members "分叉数")&nbsp;&nbsp;[🏠`https://ld246.com/tag/lute`](https://ld246.com/tag/lute "项目主页")</span>

📝一款将 Markdown 文本转换为 Word 文档 (.docx) 的小工具。



---

### 9. [lute-pdf](https://github.com/88250/lute-pdf) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`13`](https://github.com/88250/lute-pdf/stargazers "收藏数")&nbsp;&nbsp;[🖖`4`](https://github.com/88250/lute-pdf/network/members "分叉数")&nbsp;&nbsp;[🏠`https://ld246.com/tag/lute`](https://ld246.com/tag/lute "项目主页")</span>

📝一款将 Markdown 文本转换为 PDF 的小工具。



---

### 10. [awesome-solo](https://github.com/88250/awesome-solo) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`10`](https://github.com/88250/awesome-solo/stargazers "收藏数")&nbsp;&nbsp;[🖖`3`](https://github.com/88250/awesome-solo/network/members "分叉数")</span>

🎸 展示大家漂亮的 Solo 博客！最新统计数据已经移到社区 https://hacpai.com/top/solo



---

### 11. [88250](https://github.com/88250/88250) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`9`](https://github.com/88250/88250/stargazers "收藏数")&nbsp;&nbsp;[🖖`12`](https://github.com/88250/88250/network/members "分叉数")</span>

海阔天空



---

### 12. [latke-demo](https://github.com/88250/latke-demo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`8`](https://github.com/88250/latke-demo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/latke-demo/network/members "分叉数")&nbsp;&nbsp;[🏠`https://ld246.com/article/1466870492857`](https://ld246.com/article/1466870492857 "项目主页")</span>

Latke demo. 



---

### 13. [lute-http](https://github.com/88250/lute-http) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`8`](https://github.com/88250/lute-http/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/88250/lute-http/network/members "分叉数")&nbsp;&nbsp;[🏠`https://ld246.com/article/1569240189601`](https://ld246.com/article/1569240189601 "项目主页")</span>

Ⓜ️ 包装 Lute 引擎以 HTTP 服务发布。



---

### 14. [forward-proxy](https://github.com/88250/forward-proxy) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`4`](https://github.com/88250/forward-proxy/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/forward-proxy/network/members "分叉数")</span>

一款简单的 HTTP 正向代理服务。



---

### 15. [gowebdav](https://github.com/88250/gowebdav) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`3`](https://github.com/88250/gowebdav/stargazers "收藏数")&nbsp;&nbsp;[🖖`3`](https://github.com/88250/gowebdav/network/members "分叉数")</span>

Go WebDAV 客户端库。



---

### 16. [header](https://github.com/88250/header) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`3`](https://github.com/88250/header/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/88250/header/network/members "分叉数")</span>

📄 A utility to add source code file header/license written in golang. 



---

### 17. [bing](https://github.com/88250/bing) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`2`](https://github.com/88250/bing/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/bing/network/members "分叉数")&nbsp;&nbsp;[🏠`https://b3logfile.com/bing/20171104.jpg`](https://b3logfile.com/bing/20171104.jpg "项目主页")</span>

🍱 Bing 壁纸上传七牛云。 



---

### 18. [hacker-howto](https://github.com/88250/hacker-howto) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[⭐️`2`](https://github.com/88250/hacker-howto/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/hacker-howto/network/members "分叉数")</span>

本文原文由知名Hacker Eric S. Raymond 所撰写，教你如何成为一名黑客。



---

### 19. [chainbook](https://github.com/88250/chainbook) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/88250/chainbook/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/chainbook/network/members "分叉数")&nbsp;&nbsp;[🏠`https://hacpai.com/chainbook`](https://hacpai.com/chainbook "项目主页")</span>

📚 区块链上的纸质书交易平台，为未来而构建！



---

### 20. [go-markdown-benchmark](https://github.com/88250/go-markdown-benchmark) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/88250/go-markdown-benchmark/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/88250/go-markdown-benchmark/network/members "分叉数")</span>

Golang markdown engine benchmark.



---

### 21. [hits](https://github.com/88250/hits) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/88250/hits/stargazers "收藏数")&nbsp;&nbsp;[🖖`5`](https://github.com/88250/hits/network/members "分叉数")</span>

:octocat:🔢 GitHub 仓库浏览计数。



---

### 22. [iGitHub](https://github.com/88250/iGitHub) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/88250/iGitHub/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/iGitHub/network/members "分叉数")&nbsp;&nbsp;[🏠`https://ld246.com/CHANGE_LOGS.html`](https://ld246.com/CHANGE_LOGS.html "项目主页")</span>

:octocat: Exports GitHub issues to Markdown.



---

### 23. [.github](https://github.com/88250/.github) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/88250/.github/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/88250/.github/network/members "分叉数")</span>

:octocat: Community health files.



---

### 24. [88250.github.io](https://github.com/88250/88250.github.io) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/88250/88250.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/88250.github.io/network/members "分叉数")&nbsp;&nbsp;[🏠`https://88250.github.io`](https://88250.github.io "项目主页")</span>

Solo 导出的静态站点。



---

### 25. [CodeMirror](https://github.com/88250/CodeMirror) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/88250/CodeMirror/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/CodeMirror/network/members "分叉数")&nbsp;&nbsp;[🏠`http://codemirror.net/`](http://codemirror.net/ "项目主页")</span>

In-browser code editor



---

### 26. [Comfortably-Numb](https://github.com/88250/Comfortably-Numb) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/88250/Comfortably-Numb/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/Comfortably-Numb/network/members "分叉数")</span>





---

### 27. [css](https://github.com/88250/css) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/88250/css/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/css/network/members "分叉数")</span>

Basic css parser in golang



---

### 28. [dev-static-server](https://github.com/88250/dev-static-server) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/88250/dev-static-server/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/dev-static-server/network/members "分叉数")</span>

开发环境用静态资源 HTTP 伺服器。



---

### 29. [kityminder-core](https://github.com/88250/kityminder-core) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/88250/kityminder-core/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/kityminder-core/network/members "分叉数")</span>

强大的脑图可视化工具



---

### 30. [markdown-http](https://github.com/88250/markdown-http) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/88250/markdown-http/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/88250/markdown-http/network/members "分叉数")</span>

包装 Markdown 处理器以 HTTP 服务发布。

