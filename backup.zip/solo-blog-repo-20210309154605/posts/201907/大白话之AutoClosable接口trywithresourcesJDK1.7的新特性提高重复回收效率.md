title: 大白话之AutoClosable接口 | try-with-resources：JDK1.7的新特性，提高重复回收效率
date: '2019-07-02 14:04:51'
updated: '2019-12-08 20:31:42'
tags: [大白话, 语言特性, Java]
permalink: /articles/2019/07/02/1562047491184.html
---
![](https://img.hacpai.com/bing/20180604.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 前言

无论是使用文件IO流，还是网络Socket流，都免不了调用`close()`将流关闭。如果需要操作的流过多，就会导致混乱。
一旦忘记将关闭方法放到`finally`中，很有可能出现流未被关闭，占用大量内存空间的问题。

# 流程简化

## 对比

### try-catch-finally

```
        AC ac = null;
        AC2 ac2 = null;
        try {
            ac = new AC();
            ac2 = new AC2();
        } catch (Exception e) {
        } finally {
            ac.close();
            ac2.close();
        }
```

### try-with-resources

```
        try (AC ac = new AC();
             AC2 ac2 = new AC2()) {
        } catch (Exception e) {
        }
```

可以很明显的看到，`try-with-resources`会自动调用类中的`close()`方法，简化了流程，提高了代码的整洁度。

# AutoCloseable

`AutoCloseable`是Java的内置接口，继承这个接口并且按要求新建`close()`方法，该类就能被`try-with-resources`语法所支持。

## 示例

还记得我们刚才演示使用的两个类：`AC`和`AC2`吗？它们的代码如下：

### AC.java

```
public class AC implements AutoCloseable {
    @Override
    public void close() throws Exception {
        System.out.println("Program has been closed pretended.");
    }

    //默认静态方法，在被实例化时执行
    static {
        System.out.println("Program running.");
    }
}
```

### AC2.java

```
public class AC2 implements AutoCloseable {
    @Override
    public void close() throws Exception {
        System.out.println("Program 2 has been closed pretended.");
    }

    static {
        System.out.println("Program 2 running.");
    }
}
```

`AC2`和`AC`在实现上是相同的。我创建两个类的原因是想让大家知道`try-with-resources可以支持同时进行多个类的关闭`。再编写一个主方法，运行测试：

### Main.java

```
public class Main {
    public static void main(String[] args) {
        try (AC ac = new AC();
             AC2 ac2 = new AC2()) {
            //这里假装执行了有用的代码
            Thread.sleep(2000);
        } catch (Exception e) {
        }
    }
}
```

## 测试

### 运行结果

```
Program running.
Program 2 running.
（这里有2秒的延时）
Program 2 has been closed pretended.
Program has been closed pretended.
```

可以看到，`try-with-resource`对类进行了实例化，并且在代码执行完毕后进行了回收（调用了各个类的`close()`方法）。

# 后语

## 思考

仔细分析运行结果，你会发现该语法的运行规律是**先进后出，后进先出**。`AC2`是最后被实例化的，但却是第一个被关闭了。

这种机制像什么？如果你对计算机原理有所研究的话，你会发现，**堆栈**就是**先进后出**的机制。

当然，由于`try-with-resources`是Java的“语法糖”，我的知识还无法追踪到它的源码（JVM）当中去。但我们可以基本确定，`try-with-resources`的实例化和回收机制，就是用类似堆栈的算法来实现的。
