title: 大白话之Java面向接口编程：最“正经”的中文实例讲解，看不懂来打我！
date: '2019-06-03 14:24:31'
updated: '2019-12-09 09:43:48'
tags: [大白话, Java, 接口, 设计模式]
permalink: /articles/2019/06/03/1559543071037.html
---
# 前言

作为一个正经博主，我会用最**纯洁易懂**的方式让你理解面向接口编程。

阅读本篇文章，你需要对以下知识有所了解：

* 面向对象编程基础知识
* 接口（[这儿有](https://www.stackoverflow.wiki/blog/articles/2019/03/11/1552316547427.html)）

# 实例

废话少说。打开你的IDE（没有？去下！），新建一个类，命名为`Main`，复制下方代码：

```
interface 动作 {
    void 结婚();
    void 生孩子();
}

class 如花 implements 动作 {
    @Override
    public void 结婚() {
        System.out.println("为什么？");
    }

    @Override
    public void 生孩子() {
        System.out.println("凭什么？");
    }
}

class 美女 implements 动作 {
    @Override
    public void 结婚() {
        System.out.println("就现在！");
    }

    @Override
    public void 生孩子() {
        System.out.println("就今晚！");
    }
}

class 帅气的我 {
    private 动作 小姐姐;

    public 动作 我女朋友是谁() {
        return 小姐姐;
    }

    public void 指定女友(动作 小姐姐) {
        this.小姐姐 = 小姐姐;
    }

    public 帅气的我() {}

    public 帅气的我(动作 小姐姐) {
        this.小姐姐 = 小姐姐;
    }

    public void 我要结婚(){
        this.小姐姐.结婚();
    }

    public void 我要生孩子(){
        this.小姐姐.生孩子();
    }
}

public class Main {
    public static void main(String[] args) {
        帅气的我 欧巴 = new 帅气的我();
        动作 如花本人 = new 如花();
        动作 美女本人 = new 美女();

        欧巴.指定女友(如花本人);
        欧巴.我要结婚();

        欧巴.指定女友(美女本人);
        欧巴.我要生孩子();
    }
}
```

**别急着运行**！多看两遍，猜猜运行结果会是什么？

# 解析

结构不难，让我们来捋一捋。

接口|接口功能|接口继承|实现功能|实现方法
---|---|---|---|---
动作|结婚|如花|`System.out.println("为什么？");`|`new 如花().结婚();`
---|---|美女|`System.out.println("就现在！");`|`new 美女().结婚();`
动作|生孩子|如花|`System.out.println("凭什么？");`|`new 如花().生孩子();`
---|---|美女|`System.out.println("就今晚！");`|`new 美女().生孩子();`

而`帅气的我`是包装类，可以`指定new出的女友实例`，并对该女友通过`帅气的我`执行指定的方法。

# 后语

我们可以将面向接口的编程步骤做个整理：

* `动作`接口规定了可以对女生做的“动作”；
* `美女`和`如花`类继承了`动作`类，并规定了对动作产生的反应（执行的方法）；
* `帅气的我`可以接收实例化（new）后的女友对象，并对其使用`结婚`和`生孩子`两种方法。

> 祝大家早日脱单！
