title: 🎨 适用于 Solo / Bolo 的清新高级主题 —— Sakura | 移植自 WordPress 主题
date: '2020-03-28 16:41:37'
updated: '2020-03-28 23:06:31'
tags: [Solo, Bolo, 主题]
permalink: /articles/2020/03/28/1585384897191.html
---
![](https://img.hacpai.com/bing/20190626.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## ❤️喜欢该主题请为我点个 Star ~

肝爆三天三夜移植主题，如果你喜欢 `Sakura` 主题，欢迎为我 Star：

`sakura-for-bolo-and-solo` 主题的 GitHub 仓库地址：[https://github.com/adlered/sakura-for-bolo-and-solo](https://github.com/adlered/sakura-for-bolo-and-solo)

另外，也感谢来自 `WordPress` 的 `Sakura` 皮肤的原作者 `Mashrio` ：[WordPress 主题 Sakura 🌸](https://2heng.xin/theme-sakura/)

## 适用博客系统

[Solo](https://github.com/88250/solo) `3.7.0 及以上版本`  
[菠萝博客](https://github.com/adlered/bolo-solo) `v1.0 及以上版本`  

## 使用方法

1. **Clone** 本项目（使用命令 `git clone https://github.com/adlered/sakura-for-bolo-and-solo`）  
2. 找到 `skins` 目录，将 `solo-sakura` （Bolo 则  `bolo-sakura`）连着文件夹一起扔进去，重启服务端即可在后台找到  

## 预览图

### 建议直接到 Demo 网站尝试：[https://demo.stackoverflow.wiki?skin=bolo-sakura](https://demo.stackoverflow.wiki?skin=bolo-sakura)

![1.png](https://img.hacpai.com/file/2020/03/1-b2de1d6f.png)  
![2.png](https://img.hacpai.com/file/2020/03/2-00daa8ac.png)  
![3.png](https://img.hacpai.com/file/2020/03/3-66623a10.png)  
![4.png](https://img.hacpai.com/file/2020/03/4-a6afdd91.png)

## Solo 用户注意

* 如果你开启了 `jsDelivr加速` 功能，请关闭，**否则将无法正常加载皮肤**：[参数请看这里](https://hacpai.com/article/1492881378588#%E5%A6%82%E4%BD%95%E4%BD%BF%E7%94%A8-jsDelivr-CDN-%E6%9D%A5%E5%8A%A0%E9%80%9F-)

> 低版本无法运行此皮肤，也暂不考虑低版本的适配。你的 Solo 版本应支持 `静态化` 功能（v3.7.0 及以后的版本）  

## Bolo 用户注意

> Bolo 计划于 `v1.6` 版本内置该皮肤，届时请注意公告
