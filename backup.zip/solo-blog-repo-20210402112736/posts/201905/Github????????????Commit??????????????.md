title: Github仅保留指定文件/文件夹当前Commit，删除所有历史记录，清除「敏感信息」
date: '2019-05-02 20:41:27'
updated: '2019-12-09 09:46:05'
tags: [GitHub]
permalink: /articles/2019/05/02/1556800887176.html
---
# 前言
之前在Github上发布过一个项目，今天突然想起来：
**有个不该上传的东西被我上传上去了！**
于是便修改了源代码，**但是**在History中还是能看到以前的提交记录！

### 慌!
在网上查找了半天，发现都是使用`git filter-branch`进行清除，但我的项目有点特殊：
**这个敏感信息，早在第一次就提交过了！**
而`git filter-branch`还有其它方法是对项目进行回滚，达到删除Commit记录的目的，对我来说是无效的。

## BFG

最后发现了一个神器：**BFG-Repo-Cleaner**
它能清除掉你指定文件/文件夹名在项目中的所有痕迹！

### 下载

#### 对于macOS

如果你安装了Homebrew，可以使用如下命令安装BFG：

```
brew install bfg
```

使用如下命令使用BFG：

```
bfg [命令]
```

#### 对于Linux和未安装Homebrew的macOS

```
wget https://repo1.maven.org/maven2/com/madgag/bfg/1.13.0/bfg-1.13.0.jar
```

使用wget下载BFG。它会在你所在目录出现，你可以通过如下命令使用BFG：

```
java -jar bfg-1.13.0.jar [命令]
```

<pre><code class="hljs">注：需要先安装<b>Java环境</b>才能运行BFG。</code></pre>

#### 对于Windows

**请注意：Windows系统默认不安装Java环境，请自行安装Java环境并配置环境变量！**

使用任意下载器下载文件：

```
https://repo1.maven.org/maven2/com/madgag/bfg/1.13.0/bfg-1.13.0.jar
```

使用cmd，并切换到下载目录，执行如下命令使用BFG：

```
java -jar bfg-1.13.0.jar [命令]
```

### Clone项目并清除

将你的Git项目Clone到本地：

```
git clone https://github.com/AdlerED/Slog4J.git
```

将后面的项目地址修改为你自己的项目地址。

### 清除特定文件痕迹

现在，进入到项目的根目录，并执行

```
bfg --delete-files Tester.java --no-blob-protection
```

其中：
**Tester.java** 是我要彻底抹除痕迹的文件名，**不需要也不能**填写目录，bfg会删除该文件名的所有痕迹；
**--no-blob-protection** bfg默认不会删除当前分支下的文件，如需删除，须添加本参数；
**--delete-files** 代表删除指定文件，将其替换为**--delete-folders**可以删除指定文件夹。

### 手动删除文件

还没结束，BFG并没有删除原文件，只是删除了`.git`中的所有记录，你需要手动去删除这个文件。删除后，你就可以重新将该项目Commit并Push到Github了：

```
git commit --no-verify
git push -u origin master --force
```

# 后语

至此，你的错误已经被“抹去”了，但也要顺便提醒一下：

代码千万条，
安全第一条。
测试不规范，
老板两行泪。
