title: 为IDEA/Git配置GPG密钥，点亮GitHub Verified Commit标识
date: '2021-03-06 18:05:47'
updated: '2021-03-06 18:06:46'
tags: [GitHub, 开源, 知识讲解, Encryption]
permalink: /articles/2021/03/06/1615025147784.html
---
![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/18/06/69967930-449d-4c7b-a59c-d5407ba4d3e2.png)


# 前言

为 Git 设置一个 GPG 密钥后，将在每次 Commit 时确认你配置的密码，并在 GitHub 的 Commit 中显示 `Verified` 标识，以此标记这个 Commit 确实是由你本人完成的，而不是其他人的假冒。

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/17/5e59a460-2f03-42ea-be9f-7e2e6ada7076.png)

# 教程

### 系统环境

> 操作系统版本：Windows 10 X64
> 使用的IDE：Intellij IDEA

### 安装

[点击这里下载并安装GPG工具](https://www.gnupg.org/download/)，按照下图中指示下载安装程序

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/21/1c0e8b2f-1b0d-4bab-8f38-d23959272fa1.png)

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/21/2b9bea5b-ec8f-47dd-adc7-c29f8cb45f18.png)

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/22/eb64762c-9c11-4791-855b-09c8c1447ae6.png)

### 生成一个新的密钥

首先，我们需要生成一个带有个人信息的 GPG 密钥。

##### 生成密钥

```
gpg --full-generate-key
```

1. 首先 GPG 会询问生成何种加密类型的密钥，`直接按回车`，默认 RSA and RSA 方式即可
2. 询问密钥位数，`输入 4096 后按回车`（GitHub 仅接受 4096 位及以上的位数，安全性更强）
3. 询问密钥的过期时间，我们一般是不希望密钥过期的，`直接按回车`默认不过期即可
4. 询问 “Is this correct?”确认信息输入无误后，`输入 y 并回车`

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/26/5622c68f-102c-4ab8-bf87-0267e54c9011.png)

##### 输入个人信息

确认信息无误后，还需要一些你的个人信息。

1. 询问 `Real name`，填写你的英文名后回车提交即可（可以和 GitHub 的用户名不同）
2. 询问 `Email address`，一定要填写在你的 GitHub 中认证过的邮箱地址
3. 询问 `Comment`，备注，填写 `GitHub Key`（随便填都可以）
4. 按 o （英文字母）并回车，保存更改

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/31/a7d6a3ef-a718-49c1-bb1f-aed8d8a9d3db.png)

##### 设置密码

在设置个人信息后，你的电脑会弹出一个密码输入窗口，输入两次相同的密码，为密钥设置密码（一定要记住密码）

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/34/c24b574f-ece8-49be-87d0-fc0e1e6e0c4e.png)

##### 生成完毕

等待证书生成完成（如果生成的很慢，可以在终端里随便按一些英文字母，随便滑两下鼠标，给密钥生成提供一些随机熵）

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/36/6ba31d74-13a2-4927-b2aa-acf9b46eb956.png)

### 将密钥绑定至 GitHub

##### 输入命令获取你的 GPG Key ID

```
gpg --list-secret-keys --keyid-format LONG
```

找到 `uid` 行和你刚刚设置的信息相同的字段，在 `uid` 行的上一 `sec` 行找到你的 GPG Key ID，本次实验的 GPG Key ID 为 `58F7B5539BF1B95B`，记住它，一会我们要用到几次

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/38/f4fd4987-de0e-4e33-8d9d-8523f36db364.png)

##### 导出完整公钥

使用命令

```
gpg --armor --export [GPG Key ID]
```

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/41/f9f18acc-acb3-48c7-ba00-217e272db579.png)

会生成一段很长的公钥内容，将从 `-----BEGIN PGP PUBLIC KEY BLOCK-----` 开头，以 `-----END PGP PUBLIC KEY BLOCK-----` 为结尾（包括这两行）的内容复制下来

##### 将公钥放到 GitHub 中

进入 GitHub，访问你的用户设定界面

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/44/f1a0699b-e148-4bc4-be48-16728162b30b.png)

找到 `SSH and GPG Keys` 选项卡，点击 `New GPG key` 按钮（不要点错，不要点错，不要点错）

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/44/dd5d9f2a-62a6-47a5-b984-08e5ee6eff10.png)

粘贴公钥并保存

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/45/daff9686-1520-4154-b3c1-c3230e938b03.png)

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/46/79994d4a-a803-4856-87f1-2815d8116cba.png)

### 将密钥绑定至本地 Git

IDEA 调用的是本地的 Git，所以将 Git 直接配置好 GPG Key 即可。

##### 确定 Git 设定的邮箱是否正确

使用命令 `git config --global user.email` 查看当前 git 命令所使用的邮箱地址，如果不对，请使用 `git config --global user.email "新的邮箱地址"` 进行更新。

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/48/e18f48b2-423a-466e-888f-a68a61afa53a.png)

##### 为 Git 指定 GPG Key ID

还记得刚刚查询的 GPG Key ID 吗？让 git 知道它该使用这个 GPG Key。

```
git config --global user.signingkey [你的 GPG Key ID]
```

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/49/ad4ea258-f920-405c-b3f3-67c100e84203.png)

##### 将所有本地 Commit 默认使用 GPG 进行签名

> 如果不操作本步骤，默认的 commit 还是会直接跳过签名，你可以通过在 commit 时加入 `-S` 参数来临时使用 GPG 进行签名。

```
git config --global commit.gpgsign true
```

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/55/b46f7591-9a67-4906-a67e-38879fdd4974.png)



##### 指定 GPG 程序所在位置

Git 每次 commit 需要向 GPG 程序查找你的 GPG Key，由于新版 GPG 程序的程序目录有变更，Git 程序可能会找不到它而报错，使用命令

```
git config --global gpg.program "C:\Program Files (x86)\GnuPG\bin\gpg.exe"
```

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/52/2789499d-0941-4767-9692-06d5686481c1.png)

文中设定的 `gpg.exe` 所在位置可能和你安装的位置不同，请仔细核对后设定。

### 测试

一切就绪，在你的 IDEA 中进行一次 Commit，并且 Push 到 GitHub 中试试吧：

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/57/eb0d4028-fb83-4457-906c-bb2929aeccfb.png)

每次 Commit 都需要验证密钥的密码进行验证：

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/57/7630a32c-6cea-4d15-8814-c4b6131cdd12.png)

再 Push 到 GitHub 试试看：

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/59/1ed96e0a-d894-4156-a21f-b5ad6b4fd8a6.png)

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/17/58/f187c02d-ebd7-4d36-a9fe-ec56d8322846.png)

![image.png](https://pic.stackoverflow.wiki/uploadImages/106/13/71/6/2021/03/06/18/00/a38d170a-0eaf-44dc-88ad-1a67af976c01.png)

加密成功，赞。

# 后语

[官方文档](https://docs.github.com/en/github/authenticating-to-github/managing-commit-signature-verification)原文：

> You can sign your work locally using GPG or S/MIME. GitHub will verify these signatures so other people will know that your commits come from a trusted source. GitHub will automatically sign commits you make using the GitHub web interface.

> 您可以使用 GPG 或 S/MIME 在本地签名您的作品。GitHub 将验证这些签名，以便其他人知道您的提交来自受信任的来源。GitHub 在您使用 GitHub Web 时将自动对 Commits 进行签名。

