title: 随笔 | 奇淫技巧 | Java：记return和短路运算符的妙用
date: '2019-06-21 10:48:59'
updated: '2019-12-09 09:42:36'
tags: [随笔, 奇淫技巧, Java]
permalink: /articles/2019/06/21/1561085339073.html
---
在阅读`AtomicStampedReference`的源码中，在`compareAndSet()`方法发现一段代码：

```
        return
            expectedReference == current.reference &&
            expectedStamp == current.stamp &&
	    //上方条件全部符合且为True时，执行下方代码
            ((newReference == current.reference &&
              newStamp == current.stamp) ||
             casPair(current, Pair.of(newReference, newStamp)));
```

即在return执行方法，并获取最终结果。我编写了一段代码用以测试：

```
public class Main {
    public static void main(String[] args) {
        Main main = new Main();
        System.out.println(
                main.executeIsTrue()
        );
        System.out.println();
        System.out.println(
                main.executeIsFalse()
        );
    }

    boolean executeIsTrue() {
        return
                //这行判断结果为True，可以执行say(String word)方法
                (retTrue() && retTrue()) &&
                        //上述两条都为True，则执行下面代码
                        (print("OK"));
    }

    boolean executeIsFalse() {
        return
                //这行判断结果为False，不能执行say(String word)方法
                (retTrue() && retFalse()) &&
                       //上述两条都为True，则执行下面代码
                        (print("OK"));
    }

    boolean retTrue() { return true; }
    boolean retFalse() { return false; }

    boolean print(String word) { System.out.println(word); return true; }
}
```

得到返回结果：

```
OK
true

false
```

摘自[https://www.cnblogs.com/yxiaooutlook/p/7606277.html](https://www.cnblogs.com/yxiaooutlook/p/7606277.html)：

```
System.out.println(true && false); //结果为false  
System.out.println(true && true); //结果为true  
System.out.println(false && false); //结果为false  
System.out.println(false && true); //结果为false
```

即充分利用判断运算符（&&、||）返回boolean的短路，实现**在return中实现类似if语句的判断**。
