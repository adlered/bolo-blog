title: 大白话之Java级联调用：一个类，一条语句，同时调用好几个方法，串成一串
date: '2019-07-18 11:43:23'
updated: '2019-12-09 22:30:18'
tags: [大白话, Java, 奇淫技巧]
permalink: /articles/2019/07/18/1563421403678.html
---
# 前言

之前偶然学习了一下Dart编程语言（不是重点），在学习官方手册时发现一个新的概念：`级联调用`。这是啥东西？

于是我百度了以后，发现在Java中也有类似的级联调用，那它们的区别又在哪儿呢？

-:books:-|需要先了解的知识|-:books:-
语言|内容|链接
---|---|---
Java|类、方法、变量|null

-:star:-|评分|-:star:-
知识等级|实用性|罕见性
---|---|---
基础|实用|少见

# 上手

级联调用很简单，只要稍微分析下下面的源码，就懂了。

## !级联

首先我们不用级联来实现：

```
public class 级联 {
    public static void main(String[] args) {
        //实例化Guys
        Guys guys = new Guys();
	//执行方法
        guys.boy();
        guys.girl();
        guys.gentleman();
        guys.lady();
    }
}

class Guys {
    public void girl() {
        System.out.println("Hey, girl!");
    }

    public void boy() {
        System.out.println("Oh, boy!");
    }

    public void lady() {
        System.out.println("Greetings, lady!");
    }

    public void gentleman() {
        System.out.println("Nice to meet your, gentle!");
    }
}
```

得到运行结果：

```
Oh, boy!
Hey, girl!
Nice to meet your, gentle!
Greetings, lady!
```

没毛病，对吧。

## 级联

现在，我们使用级联再来实现一次：

```
public class 级联 {
    public static void main(String[] args) {
        //实例化Guys
        Guys guys = new Guys();
        //执行方法
        guys.boy().girl().gentleman().lady();
    }
}

class Guys {
    public Guys girl() {
        System.out.println("Hey, girl!");
        //把类再返回给你
        return this;
    }

    public Guys boy() {
        System.out.println("Oh, boy!");
        return this;
    }

    public Guys lady() {
        System.out.println("Greetings, lady!");
        return this;
    }

    public Guys gentleman() {
        System.out.println("Nice to meet your, gentle!");
        return this;
    }
}
```

得到运行结果：

```
Oh, boy!
Hey, girl!
Nice to meet your, gentle!
Greetings, lady!
```

## this

`public Guys xxx() {`

可以看到，我们每个方法都固定了返回值类型为`Guys`，即它的母类。

而在方法的最后：

`return this;`

`this`指向了它的母类`Guys`，所以当用户调用完以后，它就会再次返回一个`Guys`类，也就可以再次执行类中的方法了。

# 应用

感谢[csfwff](https://hacpai.com/member/csfwff)的补充：

> 级联调用也可以成为**链式调用**，在建造者模式（设计模式中的一种）中很常见。在我们要构建一个比较大的对象时，设定的值可能很多。通过链式调用，我们可以更有逻辑、方便地对其进行赋值。

## 例

使用建造者模式的伪代码：

```
        Person person = new Person();
        person.setName("CXK");
        person.setAge("20");
        person.setGender("男");
        person.setCareer("唱跳Rap篮球");
```

使用链式调用（级联调用）后的伪代码：

```
        Person person = new Person();
        person.setName("CXK");
              .setAge("20");
              .setGender("男");
              .setCareer("唱跳Rap篮球");
```

另外，经D大（[@88250](https://hacpai.com/member/88250)）指出，从更广义上来讲，也叫做**平滑接口**（FluentInterface）：
[https://martinfowler.com/bliki/FluentInterface.html](https://martinfowler.com/bliki/FluentInterface.html)

# 后语

某些场景中，可能需要多次调用同一个类中的方法，这时候级联调用就很好地保证了语句的连贯性和可读性，好极了。

但缺点也是比较明显的——执行后的值无法直接返回，因为它要返回它的母类。所以级联调用比较适用于不需要返回值的场景，或是设定一个静态的公共值（要注意线程安全问题，[点我学习](https://www.stackoverflow.wiki/blog/articles/2019/06/11/1560256379324.html)），在运行过程中进行修改。
