title: 实例带你获取多线程Thread的返回值之 (壹) - Callable的运行
date: '2019-03-17 16:19:46'
updated: '2019-12-09 09:53:04'
tags: [Java, Coding]
permalink: /articles/2019/03/15/1552618346637.html
---
# 前言

阅读本篇文章，你需要先理解以下知识：
* 多线程Thread的基本使用 （[点我跳转](https://www.stackoverflow.wiki/blog/articles/2019/03/15/1552618569953.html)）
* extends和implements
* 重写Override
* try catch错误处理
* Java基础知识

# 回顾

回顾一下我们学过的Thread多线程，是继承了一个`Thread`类，然后调用`run()`方法来执行定义的类。

那么问题来了，有时候我们需要多线程传回一个计算的值给我们，`Callable`就很好地解决了我们的需求。

# 拷贝

在你的IDE中新建一个项目或一个类，并将类命名为``CallableDemo``，然后拷贝下面这些代码：

```
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

public class CallableDemo {
    public static void main(String[] args) {
        //实例化当前类
        CallableDemo callableDemo = new CallableDemo();
        //调用动态类
        callableDemo.run();
    }

    public void run() {
        ThreadC threadC = new ThreadC();
        //使用FutureTask接收Callable运行的结果
        FutureTask futureTask = new FutureTask(threadC);
        //启动线程
        new Thread(futureTask).start();
        //获取返回结果
        try {
            Object ret = futureTask.get();
            System.out.println("获得返回结果: " + ret);
        } catch (InterruptedException | ExecutionException e) {
            System.out.println("获取结果出错");
        }
    }
}

class ThreadC implements Callable {
    @Override
    public Object call() throws Exception {
        String a = "WeChat: 1101635162";
        return a;
    }
}
```

让我们**无视掉主方法**，它用于实例化当前类并调用动态的`run()`方法。将注意力转移到`run()`方法和`ThreadC`类。

## 继承了Callable接口的类

```
class ThreadC implements Callable {
    @Override
    public Object call() throws Exception {
        String a = "WeChat: 1101635162";
        return a;
    }
}
```

可以看到，我们的`ThreadC`类继承了Callable接口，且重写了`Callable`接口的`call()`方法，使其返回一串字符串。

## 调用方法

```
    public void run() {
        ThreadC threadC = new ThreadC();
        //使用FutureTask接收Callable运行的结果
        FutureTask futureTask = new FutureTask(threadC);
        //启动线程
        new Thread(futureTask).start();
        //获取返回结果
        try {
            Object ret = futureTask.get();
            System.out.println("获得返回结果: " + ret);
        } catch (InterruptedException | ExecutionException e) {
            System.out.println("获取结果出错");
        }
    }
```

在该方法中，我们实例化了`ThreadC`。与普通的Thread不同的是我们使用了`FutureTask`类。该类用来接收`Callable`的返回结果。

剩下的代码便很好理解了，获取结果并输出。

# 运行!

现在让我们运行该类，并查看结果：

```
获得返回结果: WeChat: 1101635162
```

# 后语

本篇文章描述了简单的Callable使用方法，下一章我们将把Callable套用到线程池当中来。（[点我跳转](https://www.stackoverflow.wiki/blog/articles/2019/03/15/1552640855004.html)）
