title: 一个实例理解Java Runnable多线程用处与用法
date: '2019-03-17 16:20:41'
updated: '2019-12-09 09:51:37'
tags: [Java, Coding]
permalink: /articles/2019/03/15/1552654034725.html
---
# 前言

阅读本篇文章，你需要先理解以下知识：
* Thread多线程（[点我跳转](https://stackoverflow.wiki/blog/articles/2019/03/15/1552618569953.html)）
* 接口（interface）是什么 （[点我跳转](https://stackoverflow.wiki/blog/articles/2019/03/11/1552316547427.html)）

# 回顾

在阅读上一篇“Java Thread多线程”后，相信你学会了使用`extends`来调用，但它是有缺陷的。

## extends的缺点

Java的每个类只能使用`extends`继承一个类，如果在继承了`Thread`类后又想继承其它类，这是不可能的。

所以，有没有办法让`Thread`不继承而拥有线程属性呢？有的。

## 使用implements

在Java中，implements用于继承接口。每个类可以implements的接口是没有数量限制的，所以使用implements可以让该类避免继承被占用。

# 拷贝

使用你的IDE新建一个项目或类并命名为` RunnableDemo`，然后将下面的代码替换进去：
```
public class RunnableDemo {
    public static void main(String[] args) {
        runnableThread1 runnableThread1 = new runnableThread1();
        Thread thread = new Thread(runnableThread1);
        thread.run();
    }
}

class runnableThread1 implements Runnable {
    @Override
    public void run() {
        System.out.println("成功调用!");
    }
}

```

不多解释，如果你看过上篇文章（[点我跳转](https://stackoverflow.wiki/blog/articles/2019/03/15/1552618569953.html)）的话，这段代码对于你是没有难度的。

# 运行!

运行这段代码，你的控制台会显示如下结果：

```
成功调用！
```


# 后语

`implements Runnable`和`extends Thread`的效果是一样的，`Runnable`的本质也是调用了`Thread`，但相比之下不需要`extends`，从而为其它类留出了一个`extends`位置，这对后期开发是尤为有利的。
