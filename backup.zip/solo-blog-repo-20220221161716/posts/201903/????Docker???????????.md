title: 大白话之Docker(壹)：快速入门&&简单官方实例
date: '2019-03-19 11:31:55'
updated: '2019-12-09 09:49:32'
tags: [大白话, Docker]
permalink: /articles/2019/03/19/1552966314902.html
---
# 前言

无论你用的是Python，Java还是Golang或是什么语言，Docker都能以降低服务器应用耦合性（[点我了解耦合性](https://www.stackoverflow.wiki/blog/articles/2019/03/19/1552968007397.html)），方便管理等优点。值得在你的服务器中占有一席。

如果你使用过Linux或macOS，你可能对一款软件很熟悉：Wine。它用于配置一个运行环境的容器，让Windows软件在这个容器中运行，Docker与它的原理相似。

# 细读！Docker概念

我在网上看到的图大部分都很繁琐，反而会越研究越迷糊。我们从最接近我们的方向往外讲：

### 容器（Container）

容器就像虚拟机一样，是一个隔离于物理机的空间。你在里面放好需要的运行环境：比如你需要在容器里运行Python脚本，你就可以给容器安装Python，也可以在里面放入你的脚本程序。

**在容器中写入一段规定的脚本内容，你就可以让Docker启动这个容器并且按照你的脚本来执行命令。**

无论容器内的应用怎么折腾，也跑不出这个容器。

假如你在容器里配置了一个Tomcat服务器，而这个Tomcat服务器是需要Java才能运行的，只要你在容器中装好了Java，就算更换服务器后系统里没有Java也**没有任何问题**。因为容器是**被隔离的**，只要容器中环境配置好了，和物理机没有任何关系。

同理，如果你在物理机中安装了Java，但在容器中没有安装Java的话，容器中的应用是无法正常运行的，因为容器无法访问外部内容。

### 镜像（Image）

看到`镜像`这个词，如果你对计算机没有深入了解的话，你可能会联想到`光盘`，或者你会联想到安装系统用的`ISO镜像`。实际上，Docker也与这些东西出入不大。它本质就是一个**将一切都部署完毕，然后打包好**了的镜像。

当你将一个项目和它的环境部署完毕后，你就可以将它打包成镜像。当你想使用的时候，就把它解压为一个**容器**并运行。

镜像是不能运行的，只有将镜像解压为一个容器后才能被运行。

**注意：容器中所做的改动不会保存到镜像**。

### 卷（Volume）

卷就像是一块移动硬盘，哪个容器需要存储文件，就把它挂在到这个容器中。因为容器中产生的数据重启后会丢失(恢复到初始镜像状态)，所以如果需要在容器运行过程中存储文件，一定要挂载卷给容器，**卷中的文件重启Docker后不会丢失**。

**注意：除非你使用了卷，否则容器内运行期间产生的数据在容器关闭后，又将回到你启动容器时的原始镜像状态。**

# Docker环境配置

### Docker官方下载地址

#### For Windows

[Windows](https://docs.docker.com/docker-for-windows/install/)

#### For macOS

[macOS](https://docs.docker.com/docker-for-mac/install/)

#### For Linux

[CentOS](https://docs.docker.com/install/linux/docker-ce/centos/)

[Debian](https://docs.docker.com/install/linux/docker-ce/debian/)

[Fedora](https://docs.docker.com/install/linux/docker-ce/fedora/)

[Ubuntu](https://docs.docker.com/install/linux/docker-ce/ubuntu/)

安装的步骤不再过多阐述，一般情况下跟随安装向导安装即可，十分便捷。

### 登录Docker(可选)

如果要使用在线仓库，必须登录Docker才能使用，请先到：
[这里注册一个账号](https://hub.docker.com/signup)
然后在命令行中输入：

```
docker login -u [用户名] -p [密码]
```

部署完成。

### Hello World!

在命令行输入命令：

```
adler@A ~/DKT > docker run hello-world

Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
 1. The Docker client contacted the Docker daemon.
 2. The Docker daemon pulled the "hello-world" image from the Docker Hub.
    (amd64)
 3. The Docker daemon created a new container from that image which runs the
    executable that produces the output you are currently reading.
 4. The Docker daemon streamed that output to the Docker client, which sent it
    to your terminal.

To try something more ambitious, you can run an Ubuntu container with:
 $ docker run -it ubuntu bash

Share images, automate workflows, and more with a free Docker ID:
 https://hub.docker.com/

For more examples and ideas, visit:
 https://docs.docker.com/get-started/
```

如果运行出现问题，那么你可能没有**科学上网**，你懂的......
你也可以跳过本段继续学习，下章教程我们将在本地构建一个Docker镜像。

# 后语

你现在位于第一章。如果要继续学习Docker本地环境配置：
[点击这里跳转至第二章](https://www.stackoverflow.wiki/blog/articles/2019/03/19/1553004723789.html)
