title: 我在 GitHub 上的开源项目
date: '2021-03-15 13:38:29'
updated: '2021-03-15 13:43:35'
tags: [开源, GitHub]
permalink: /github
---
![GitHub Repo](https://null:-1/blog/images/github_repo.jpg)

### 1. [CSDNGreener](https://github.com/adlered/CSDNGreener) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[⭐️`2053`](https://github.com/adlered/CSDNGreener/stargazers "收藏数")&nbsp;&nbsp;[🖖`102`](https://github.com/adlered/CSDNGreener/network/members "分叉数")&nbsp;&nbsp;[🏠`https://greasyfork.org/zh-CN/scripts/378351`](https://greasyfork.org/zh-CN/scripts/378351 "项目主页")</span>

《专 业 团 队》🕺🏿 🕺🏿 🕺🏿 🕺🏿 ⚰️🕺🏿 🕺🏿 🕺🏿 🕺🏿 | 专治 CSDN 广告与各种灵魂打击 | 🐵 油猴脚本 | TamperMonkey | Chrome | FireFox | CSDN 页面浮窗广告完全过滤净化 | 国服最强 CSDN 绿化脚本



---

### 2. [bolo-solo](https://github.com/adlered/bolo-solo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`468`](https://github.com/adlered/bolo-solo/stargazers "收藏数")&nbsp;&nbsp;[🖖`85`](https://github.com/adlered/bolo-solo/network/members "分叉数")&nbsp;&nbsp;[🏠`https://demo.stackoverflow.wiki`](https://demo.stackoverflow.wiki "项目主页")</span>

🍍Bolo菠萝博客 专为程序员设计的精致Java博客系统 | 🎸基于Solo深度定制 | ❤️完善文档轻松安装，贴心的技术支持 | 免登录评论 | 邮件/微信提醒 | 自定义图床 | 备案模式 | ✨精致主题持续更新 | 一键备份 | 防火墙 | 评论过滤 | 独立分类 | 文章与GitHub同步 | ✅安装太轻松！支持 Tomcat  Docker   宝塔面板 | 支持Windows  Linux  MacOS  Web容器 | 支持ARM处理器  X86/64处理器 | 🚚支持从Solo轻松迁移



---

### 3. [DangerousSpamWords](https://github.com/adlered/DangerousSpamWords) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`33`](https://github.com/adlered/DangerousSpamWords/stargazers "收藏数")&nbsp;&nbsp;[🖖`30`](https://github.com/adlered/DangerousSpamWords/network/members "分叉数")</span>

:notes:超轻量的中文敏感字、敏感词库，字典词典，超低误识别率，另提供API调用



---

### 4. [GitHubUsersWallOnREADME](https://github.com/adlered/GitHubUsersWallOnREADME) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`15`](https://github.com/adlered/GitHubUsersWallOnREADME/stargazers "收藏数")&nbsp;&nbsp;[🖖`6`](https://github.com/adlered/GitHubUsersWallOnREADME/network/members "分叉数")</span>

:robot: 自动将GitHub用户批量渲染生成为README中的用户名&&头像墙 | :sparkles: Automatic batch rendering of GitHub users into usernames && avatar wall in README



---

### 5. [BlackBug](https://github.com/adlered/BlackBug) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`11`](https://github.com/adlered/BlackBug/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/BlackBug/network/members "分叉数")</span>

:bug: A general backdoor payload MultiClient/Server for Windows/macOS/Linux in Java | Windows/macOS/Linux通用系统后门Payload，支持多客户端主动&自动连接服务端，使用Java编写



---

### 6. [ContentEasyJS](https://github.com/adlered/ContentEasyJS) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[⭐️`7`](https://github.com/adlered/ContentEasyJS/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/adlered/ContentEasyJS/network/members "分叉数")</span>

:star2:Easily and automatically create directory navigation for your articles without configuration. | 轻松为你的网站文章设置右侧悬浮目录导航，支持点击跳转，不需要复杂的设置！JS | HTML | JQuery



---

### 7. [bce_ddns](https://github.com/adlered/bce_ddns) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`6`](https://github.com/adlered/bce_ddns/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/bce_ddns/network/members "分叉数")</span>

🚀 百度云/百度智能云域名解析DDNS | 轻松上手 | 稳定好用 | 基于Java实现



---

### 8. [FxxkingHackerPWD](https://github.com/adlered/FxxkingHackerPWD) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`5`](https://github.com/adlered/FxxkingHackerPWD/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/adlered/FxxkingHackerPWD/network/members "分叉数")</span>

:lock: 对密码、字符串进行 打乱 | 加盐 | SHA1 加/解密，用于网站用户密码的验证&&存储，让宕出数据库的Hacker手足无措吧。



---

### 9. [JavaToolBoxes](https://github.com/adlered/JavaToolBoxes) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`5`](https://github.com/adlered/JavaToolBoxes/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/JavaToolBoxes/network/members "分叉数")</span>

:art: 个人开发使用并存档的Java工具轮子集 :cn: 全中文README文档、全中文注释 :page_facing_up: JavaDoc支持 :chart_with_upwards_trend: 持续更新中



---

### 10. [JNmap](https://github.com/adlered/JNmap) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`5`](https://github.com/adlered/JNmap/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/adlered/JNmap/network/members "分叉数")</span>

:construction: 完成中 | :rotating_light: 基于Java实现的网络扫描器 | :package: 交互式扫描，比Nmap更友好，进度可视化更强 | :speech_balloon: Java-based network scanner | :chart_with_upwards_trend: Interactive scanning, more friendly than Nmap, more progress visualization



---

### 11. [KeepUrDiskAlive](https://github.com/adlered/KeepUrDiskAlive) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`5`](https://github.com/adlered/KeepUrDiskAlive/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/KeepUrDiskAlive/network/members "分叉数")</span>

:white_check_mark: 防止移动硬盘休眠神器，支持全平台 | Prevent your mobile hard drive from automatically sleeping, support all platform



---

### 12. [bolo-blog](https://github.com/adlered/bolo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`4`](https://github.com/adlered/bolo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/adlered/bolo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://null:-1/blog`](https://null:-1/blog "项目主页")</span>

✍️ 贼拉正经的技术博客 - @adlered



---

### 13. [bolo-docker](https://github.com/adlered/bolo-docker) <kbd title="主要编程语言">Shell</kbd> <span style="font-size: 12px;">[⭐️`4`](https://github.com/adlered/bolo-docker/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/bolo-docker/network/members "分叉数")&nbsp;&nbsp;[🏠`https://github.com/adlered/bolo-solo`](https://github.com/adlered/bolo-solo "项目主页")</span>

:rocket: 使用 Docker 光速部署 Bolo



---

### 14. [1970s-ConsoleGraphicFrame](https://github.com/adlered/1970s-ConsoleGraphicFrame) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`2`](https://github.com/adlered/1970s-ConsoleGraphicFrame/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/1970s-ConsoleGraphicFrame/network/members "分叉数")</span>

“初步开发” | 高性能、精简的 Java 控制台图形框架



---

### 15. [DIPzilla-Server](https://github.com/adlered/DIPzilla-Server) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`2`](https://github.com/adlered/DIPzilla-Server/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/DIPzilla-Server/network/members "分叉数")</span>

[Server 服务端] :card_file_box: A "Client(s) to Server" Dynamic IP Record System | Just like DDNS - but without domain and DNS Server | 一个"客户端到服务端"的动态IP地址记录系统 | 就像没有域名和DNS服务器的DDNS



---

### 16. [bootset](https://github.com/adlered/bootset) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/adlered/bootset/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/bootset/network/members "分叉数")</span>

!未完成! 设置特定命令开机执行并立即执行，支持Windows/Linux/MacOS



---

### 17. [DIPzilla-Client](https://github.com/adlered/DIPzilla-Client) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/adlered/DIPzilla-Client/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/DIPzilla-Client/network/members "分叉数")</span>

[Client 客户端] :iphone: A "Client(s) to Server" Dynamic IP Record System | Just like DDNS - but without domain and DNS Server | 一个"客户端到服务端"的动态IP地址记录系统 | 就像没有域名和DNS服务器的DDNS



---

### 18. [FTPTerminal4J](https://github.com/adlered/FTPTerminal4J) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/adlered/FTPTerminal4J/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/FTPTerminal4J/network/members "分叉数")</span>

:seedling:Based in bottom Socket|FTP protocol. You can execute FTP in Java like terminal's interactive. 基于底层Socket|FTP协议，你可以在Java中像在终端的FTP一样交互。



---

### 19. [adlered](https://github.com/adlered/adlered) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/adlered/adlered/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/adlered/adlered/network/members "分叉数")</span>





---

### 20. [atom](https://github.com/adlered/atom) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/adlered/atom/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/atom/network/members "分叉数")&nbsp;&nbsp;[🏠`https://atom.io`](https://atom.io "项目主页")</span>

:atom: The hackable text editor



---

### 21. [Auto-Time-Syncer](https://github.com/adlered/Auto-Time-Syncer) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/adlered/Auto-Time-Syncer/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/Auto-Time-Syncer/network/members "分叉数")</span>

:arrows_clockwise:自动同步你的系统时间 Auto sync ur system time



---

### 22. [BlogPlatformExportTool](https://github.com/adlered/BlogPlatformExportTool) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/adlered/BlogPlatformExportTool/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/BlogPlatformExportTool/network/members "分叉数")</span>

📄 博客平台备份文件的通用分析导出工具



---

### 23. [bulma-templates](https://github.com/adlered/bulma-templates) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/adlered/bulma-templates/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/bulma-templates/network/members "分叉数")&nbsp;&nbsp;[🏠`https://bulmatemplates.github.io/bulma-templates/`](https://bulmatemplates.github.io/bulma-templates/ "项目主页")</span>

free flexbox templates built with the bulma css framework



---

### 24. [CountTimeBySecond](https://github.com/adlered/CountTimeBySecond) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/adlered/CountTimeBySecond/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/CountTimeBySecond/network/members "分叉数")</span>

:watch:Format second to yyyy-mm-dd 将秒转化为年-月-日



---

### 25. [Custom-keyboard-typing-simulator](https://github.com/adlered/Custom-keyboard-typing-simulator) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/adlered/Custom-keyboard-typing-simulator/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/Custom-keyboard-typing-simulator/network/members "分叉数")</span>

:pencil:自定义键盘输入模拟 Custom keyboard typing simulator



---

### 26. [Easy-Windows-Scheduled-Task-Setter](https://github.com/adlered/Easy-Windows-Scheduled-Task-Setter) <kbd title="主要编程语言">C++</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/adlered/Easy-Windows-Scheduled-Task-Setter/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/Easy-Windows-Scheduled-Task-Setter/network/members "分叉数")</span>

:chart_with_upwards_trend:是否觉得Windows的计划任务设置太过复杂? 让它来帮助你! To makes setup "Scheduled Task" on windows more easily!



---

### 27. [FolderSizeCalculator](https://github.com/adlered/FolderSizeCalculator) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/adlered/FolderSizeCalculator/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/FolderSizeCalculator/network/members "分叉数")</span>

 :mag_right:计算指定目录下的所有目录/文件大小



---

### 28. [grabber](https://github.com/adlered/grabber) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/adlered/grabber/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/grabber/network/members "分叉数")</span>

programing language based developing on Java and C++



---

### 29. [IPSegmentScanner](https://github.com/adlered/IPSegmentScanner) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/adlered/IPSegmentScanner/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/IPSegmentScanner/network/members "分叉数")</span>

:computer:Find out the gateway FAST! e.g. If you tell scanner to scan '192.0.1.1', it will be scan '192.0.1.1', '192.1.1.1', '192.2.1.1'... by your customize!



---

### 30. [iqiyiGreener](https://github.com/adlered/iqiyiGreener) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/adlered/iqiyiGreener/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/adlered/iqiyiGreener/network/members "分叉数")</span>

:no_bell:爱奇艺iqiyi页面完全过滤净化(让你专注于视频|不影响功能使用|非跳过广告插件)

